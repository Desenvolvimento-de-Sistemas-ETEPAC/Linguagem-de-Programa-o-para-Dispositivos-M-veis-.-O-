package com.example.projetoandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastroBoletim  extends AppCompatActivity {

    EditText editNome;
    EditText editNota1;
    EditText editNota2;
    EditText editDisciplina;
    Button btnCadastrar;
    Button btnVoltar;
    float nota1;
    float nota2;
    float media;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.telaboletim);

        editNome = findViewById(R.id.editNome);
        editNota1 = findViewById(R.id.editNota1);
        editNota2 = findViewById(R.id.editNota2);
        editDisciplina = findViewById(R.id.edtiDisciplina);
        btnCadastrar = findViewById(R.id.btnCadastro);
        btnVoltar = findViewById(R.id.btnVoltar);



        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                nota1 = Float.parseFloat(editNota1.getText().toString());
                nota2 = Float.parseFloat(editNota2.getText().toString());

                media = (nota1 + nota2) / 2;
                Toast.makeText(getBaseContext(), " o estudante " +  editNome.getText() + " matriculado na  disciplina  " +  editDisciplina.getText()+ " possui média:  " +media, Toast.LENGTH_LONG).show();
            }
        });

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent telaBoletim = new Intent(CadastroBoletim.this, MainActivity.class);
                startActivity(telaBoletim);
            }
        });

    }
}

