package com.example.projetoandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends  AppCompatActivity {

        Button btnEstudante;
        Button btnBoletim;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            btnEstudante  = findViewById(R.id.btnEstudante);
            btnBoletim = findViewById(R.id.btnBoletim);

            btnEstudante.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent telaEstudante = new Intent(MainActivity.this, CadastroEstudante.class);
                    startActivity(telaEstudante);
                }
            });

            btnBoletim.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent telaBoletim = new Intent(MainActivity.this, CadastroBoletim.class);
                    startActivity(telaBoletim);
                }
            });

        }

}