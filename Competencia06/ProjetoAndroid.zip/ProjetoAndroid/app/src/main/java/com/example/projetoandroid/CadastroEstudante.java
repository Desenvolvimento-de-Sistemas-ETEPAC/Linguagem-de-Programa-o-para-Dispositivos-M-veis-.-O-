package com.example.projetoandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastroEstudante extends AppCompatActivity {

    EditText editNome;
    EditText editCPF;
    EditText editEmail;
    Button btnCadastrar;
    Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.telaestudante);

        editNome = findViewById(R.id.editNome);
        editCPF = findViewById(R.id.editCpf);
        editEmail = findViewById(R.id.editEmail);
        btnCadastrar  = findViewById(R.id.btnCadastro);
        btnVoltar  = findViewById(R.id.btnVoltar);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getBaseContext(), " O nome: " + editNome.getText()+ " com CPF " + editCPF.getText()+ " é um estudante matriculado", Toast.LENGTH_LONG).show();
            }
        });

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent telaEstudante = new Intent(CadastroEstudante.this, MainActivity.class);
                startActivity(telaEstudante);
            }
        });

    }
}

