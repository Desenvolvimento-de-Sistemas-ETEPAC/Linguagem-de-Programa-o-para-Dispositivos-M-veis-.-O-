package com.example.projetoactivity_01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button olaMundo = new Button(this);
        olaMundo.setText("EAD Pernambuco! :)");
        olaMundo.setOnClickListener(this);
        setContentView(olaMundo);
    }

    public void onClick(View v) {
        Intent tela1 = new Intent(MainActivity.this, SegundaTela.class);
        startActivity(tela1);
    }
}


