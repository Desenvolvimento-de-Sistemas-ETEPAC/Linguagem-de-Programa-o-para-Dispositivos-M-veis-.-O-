package com.example.projetoactivity_01;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SegundaTela extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tela2 = new TextView(this);
        tela2.setText("Bem vindo a SegundaTela.");
        setContentView(tela2); }
}
